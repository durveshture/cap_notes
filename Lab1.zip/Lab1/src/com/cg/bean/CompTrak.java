package com.cg.bean;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class CompTrak {
	
	@FindBy(id="txtcomputerName")
	WebElement computerName;
	
	@FindBy(id="txtdiskCapacity")
	WebElement diskCapacity;
	
	@FindBy(id="txttotalInstalledMemory")
	WebElement totalInstalledMemory;
	
	@FindBy(id="txtnetworkCardNumber")
	WebElement networkCardNumber;
	
	@FindBy(id="txtnetworkCardManufacturer")
	WebElement networkCardManufacturer;
	
	@FindBy(id="txtfreeSpace")
	WebElement  freeSpace;
	
	@FindBy(id="txtoperatingSystem")
	WebElement operatingSystem;
	
	@FindBy(id="txtosVersion")
	WebElement osVersion;

	@FindBy(id = "submit")
	private WebElement submit;
	
	public String getComputerName() {
		return computerName.getAttribute("value");
	}

	public void setComputerName(String computerName) {
		this.computerName.sendKeys(computerName); 
	}

	public String getDiskCapacity() {
		return diskCapacity.getAttribute("value");
	}

	public void setDiskCapacity(String diskCapacity) {
		this.diskCapacity.sendKeys(diskCapacity);
	}

	public String getTotalInstalledMemory() {
		return totalInstalledMemory.getAttribute("value");
	}

	public void setTotalInstalledMemory(String totalInstalledMemory) {
		this.totalInstalledMemory.sendKeys(totalInstalledMemory);
	}

	public String getNetworkCardNumber() {
		return networkCardNumber.getAttribute("value");
	}

	public void setNetworkCardNumber(String networkCardNumber) {
		this.networkCardNumber.sendKeys(networkCardNumber);
	}

	public String getNetworkCardManufacturer() {
		return networkCardManufacturer.getAttribute("value");
	}

	public void setNetworkCardManufacturer(String networkCardManufacturer) {
		this.networkCardManufacturer.sendKeys(networkCardManufacturer);
	}

	public String getFreeSpace() {
		return freeSpace.getAttribute("value");
	}

	public void setFreeSpace(String freeSpace) {
		this.freeSpace.sendKeys(freeSpace);
	}

	public String getOperatingSystem() {
		return operatingSystem.getAttribute("value");
	}

	public void setOperatingSystem(String operatingSystem) {
		this.operatingSystem.sendKeys(operatingSystem);
	}

	public String getOsVersion() {
		return osVersion.getAttribute("value");
	}

	public void setOsVersion(String osVersion) {
		this.osVersion.sendKeys(osVersion);
	}
	
	public void clickSubmit() {
		submit.click();
	}
}
