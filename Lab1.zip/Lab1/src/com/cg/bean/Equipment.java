package com.cg.bean;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

public class Equipment {
	
	@FindBy(id="txtpurchaseMethod")
	WebElement purchaseMethod;
	
	@FindBy(id="txtsequenceNumber")
	WebElement sequenceNumber;
	
	@FindBy(id="txtequipmentCode")
	WebElement equipmentCode;
	
	@FindBy(id="txtdeptId")
	WebElement deptId;
	
	@FindBy(id="txtusestatus")
	WebElement useStatus;
	
	@FindBy(id="txtcostCenter")
	WebElement costCenter;
	
	@FindBy(id="txtinstallDate")
	WebElement installDate;
	
	@FindBy(id="txtauditIndictor")
	WebElement auditIndictor;
	
	@FindBy(id="txtauditDate")
	WebElement auditDate;
	
	@FindBy(id="txtstock")
	WebElement stock;

	@FindBy(id="txtlocation")
	WebElement location;
	
	@FindBy(id="txtlocationId")
	WebElement locationId;
	
	@FindBy(id="register")       // new added
	WebElement register;
	
	public String getPurchaseMethod() {
		return purchaseMethod.getAttribute("value");
	}

	public void setPurchaseMethod(String purchaseMethod) {
		this.purchaseMethod.sendKeys(purchaseMethod); 
	}

	public String getSequenceNumber() {
		return sequenceNumber.getAttribute("value");
	}

	public void setSequenceNumber(String sequenceNumber) {
		this.sequenceNumber.sendKeys(sequenceNumber); 
	}

	public String getEquipmentCode() {
		return equipmentCode.getAttribute("value");
	}

	public void setEquipmentCode(String equipmentCode) {
		this.equipmentCode.sendKeys(equipmentCode); 
	}

	public String getDeptId() {
		return deptId.getAttribute("value");
	}

	public void setDeptId(String deptId) {
		this.deptId.sendKeys(deptId); 
	}

	public String getUseStatus() {
		return useStatus.getAttribute("value");
	}

	public void setUseStatus(int i) {
		Select select = new Select(useStatus);
		select.selectByIndex(i);
	}

	public String getCostCenter() {
		return costCenter.getAttribute("value");
	}

	public void setCostCenter(String costCenter) {
		this.costCenter.sendKeys(costCenter);
	}

	public String getInstallDate() {
		return installDate.getAttribute("value");
	}

	public void setInstallDate(String installDate) {
		this.installDate.sendKeys(installDate);
	}

	public String getAuditIndictor() {
		return auditIndictor.getAttribute("value");
	}

	public void setAuditIndictor(String auditIndictor) {
		this.auditIndictor.sendKeys(auditIndictor);
	}

	public String getAuditDate() {
		return auditDate.getAttribute("value");
	}

	public void setAuditDate(String auditDate) {
		this.auditDate.sendKeys(auditDate);
	}

	public String getStock() {
		return stock.getAttribute("value");
	}

	public void setStock(String stock) {
		this.stock.sendKeys(stock);
	}
	
	
	

	public String getLocation() {
		return location.getAttribute("value");
	}

	public void setLocation(int i) {
		Select select = new Select(location);
		select.selectByIndex(i);
	}

	public String getLocationId() {
		return locationId.getAttribute("value");
	}

	public void setLocationId(String locationId) {
		this.locationId.sendKeys(locationId);
	}
	
	public void clickRegister() {
		register.click();
	}
	
	
}
