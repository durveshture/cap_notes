package com.cg.ExceptionClass;

public class InvalidReceiverException extends Exception {

	public InvalidReceiverException() {
		// TODO Auto-generated constructor stub
	}

	public InvalidReceiverException(String message) {
		super(message);
	}
}
