package com.cg.ExceptionClass;

public class NegativeAmountException extends Exception {

	public NegativeAmountException() {
		// TODO Auto-generated constructor stub
	}

	public NegativeAmountException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}
