package com.cg.ExceptionClass;

public class SenderReceiverSameException extends Exception {

	public SenderReceiverSameException() {
		// TODO Auto-generated constructor stub
	}

	public SenderReceiverSameException(String message) {
		super(message);
	}
}
