package cg.config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import oracle.jdbc.driver.OracleDriver;

public final class JdbcFactory {

	private JdbcFactory() {}

	public static Connection getConnection() throws SQLException {
		String url = "jdbc:oracle:thin:@10.51.103.201:1521:orcl11g";
		Connection conn = null;
		OracleDriver driver = new OracleDriver();
		DriverManager.registerDriver(driver);
		conn = DriverManager.getConnection(url, "lab1ctrg8", "lab1coracle");
		return conn;
	}
}
